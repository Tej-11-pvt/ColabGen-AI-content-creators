# CollabGen Feature Overview Video

A short, subtitle-led explainer video for the CollabGen AI Content Creator Marketplace website:
https://remix-prompt-craft1-3660.ai.studio/

## Files
- `collabgen_feature_overview.mp4` — 42-second 720p/30fps explainer with burned-in subtitles.
- `subtitles_en.srt` — English subtitle track for use in video players/editors.
- `README.md` — project notes and publishing steps.

## Important accuracy note
The live website's interactive UI could not be reliably inspected during creation. This video is therefore a polished concept overview based on the marketplace description, not a verified click-by-click recording of every live feature. Review the website and update the narration/slides before presenting it as a complete feature audit.

## Publish to GitHub
1. Create a new empty repository on GitHub, for example `collabgen-feature-overview`.
2. Extract this ZIP.
3. In the extracted folder, run:

```bash
git init
git add collabgen_feature_overview.mp4 subtitles_en.srt README.md
git commit -m "Add CollabGen feature overview video"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/collabgen-feature-overview.git
git push -u origin main
```

You can then link to the video in the repository README. GitHub may recommend Git LFS if the MP4 exceeds its file-size limits.
